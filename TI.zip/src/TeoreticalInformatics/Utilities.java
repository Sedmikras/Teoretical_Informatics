package TeoreticalInformatics;

/**
 * Created by sedmikras on 17.10.16.
 */
public class Utilities {
    public static final char BLANK = ' ';
    public static final char BUTTON_0 = 'a';
    public static final char BUTTON_1 = 'b';
    public static final char BUTTON_2 = 'c';
}
